This theme is provided by fancythemes - http://fancythemes.com/

=> JS Files
--------------
Modernizr: MIT License https://modernizr.com/license/

FlexSlider: GPL v2
https://github.com/woothemes/FlexSlider/blob/master/LICENSE.md

Select2: MIT License
https://github.com/select2/select2/blob/master/LICENSE.md

=> Fonts
--------------
Font Awesome: MIT and GPL licenses
http://fontawesome.io/license/