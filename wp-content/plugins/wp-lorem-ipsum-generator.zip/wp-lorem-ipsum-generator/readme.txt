=== Lorem Ipsum Generator ===
Contributors: jonnyvaughan
Tags: lorem ipsum, lorem ipsum generator
Requires at least: 3.9
Tested up to: 3.9.2
Stable tag: trunk

Creates a button on your wysiwyg toolbars to add a configurable amount of Lorem Ipsum text to a post, page or any other custom post type.

== Description ==
Creates a button on your wysiwyg toolbars to add a configurable amount of Lorem Ipsum text to a post, page or any other custom post type.

= Key Features =
Can be used on any wysiwyg editor panel
Lets you enter how many words you\'d like to generate
Randomised paragraphs & sentences

== Installation ==
1. Download the latest vesion of the plugin to your computer
2. Extract and upload the folder wp-lorem-ipsum-generator to your /wp-content/plugins/ directory.
3. Activate the plugin your Dashboard via the \"Plugins\" menu item.

= Instructions for use =
1. Edit any page/post/custom post and click the LI button to insert text.
2. Enter the number of words to add
3. Click OK

== Changelog ==
= 0.3 =
Fixed WP installs that don\'t reside in root folder. Rewrote TinyMCE code for WP 3.9 compatability. New icon.

= 0.2.2 =
Fixed another JS library path error

= 0.2 =
Fixed js library path errors

= 0.1 =
* First release.


== Upgrade Notice ==
Fixes compatibility issues with latest version of WordPress.