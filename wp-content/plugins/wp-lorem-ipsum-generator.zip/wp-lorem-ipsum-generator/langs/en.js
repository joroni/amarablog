// English lang variables  
tinyMCE.addI18n("en.loremipsum", {
	description : "Insert Lorem Ipsum text."  
});
